import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Card from '../../components/common/Card/Card';
import Alert from '../../components/common/Alert/Alert';
import Button from '../../components/common/Button/Button';
import JobForm from '../../features/jobs/components/JobForm';
import jobService from '../../services/jobService';
import { ROUTES } from '../../routes/routePaths';
import { MOCK_JOBS } from './JobListPage';

const EditJobPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  // TODO: replace with jobService.getJobById(id) once the backend is connected
  const job = MOCK_JOBS.find((j) => j.id === id);

  if (!job) {
    return (
      <div>
        <Button variant="secondary" icon={ArrowLeft} onClick={() => navigate(ROUTES.JOBS)} className="mb-4">
          Back to job postings
        </Button>
        <Alert variant="error" title="Job posting not found">
          This job posting may have been deleted, or the link is out of date.
        </Alert>
      </div>
    );
  }

  const handleSubmit = async (formData) => {
    setLoading(true);
    try {
      await jobService.updateJob(id, formData);
    } catch (err) {
      console.error('Failed to update job', err);
    } finally {
      setLoading(false);
      navigate(ROUTES.JOB_DETAILS.replace(':id', id));
    }
  };

  return (
    <div>
      <div className="mb-5">
        <h1 className="text-xl font-bold text-slate-900">Edit job posting</h1>
        <p className="mt-1 text-sm text-slate-500">Update the role details — re-screening will use the new description</p>
      </div>

      <Card>
        <JobForm
          initialData={job}
          onSubmit={handleSubmit}
          onCancel={() => navigate(ROUTES.JOB_DETAILS.replace(':id', id))}
          submitLabel="Save changes"
          loading={loading}
        />
      </Card>
    </div>
  );
};

export default EditJobPage;
