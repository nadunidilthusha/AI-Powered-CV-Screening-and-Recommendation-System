import { useState } from 'react';
import {
  User, ShieldCheck, Bell, SlidersHorizontal, CreditCard, AlertTriangle,
  BadgeCheck, Laptop, Smartphone, Sun, Moon, Monitor, Save, Trash2,
} from 'lucide-react';
import Card from '../../components/common/Card/Card';
import Input from '../../components/common/Input/Input';
import Button from '../../components/common/Button/Button';

const TABS = [
  { key: 'profile', label: 'Profile', icon: User },
  { key: 'security', label: 'Security', icon: ShieldCheck },
  { key: 'notifications', label: 'Notifications', icon: Bell },
  { key: 'preferences', label: 'Preferences', icon: SlidersHorizontal },
  { key: 'billing', label: 'Billing & usage', icon: CreditCard },
];

/** Small on/off switch shared by the Security and Notifications sections. */
const Switch = ({ checked, onChange }) => (
  <button
    role="switch"
    aria-checked={checked}
    onClick={() => onChange(!checked)}
    className={`relative h-6 w-[42px] shrink-0 rounded-full transition-colors ${checked ? 'bg-blue-600' : 'bg-slate-300'}`}
  >
    <span
      className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
        checked ? 'translate-x-[21px]' : 'translate-x-0.5'
      }`}
    />
  </button>
);

const NOTIF_ROWS = [
  { key: 'cvDone', title: 'CVs finished processing', sub: 'When a batch upload finishes screening and ranking', email: true, inApp: true },
  { key: 'highlyRec', title: 'Highly recommended candidate', sub: 'When the AI flags a candidate as Highly Recommended', email: true, inApp: true },
  { key: 'weekly', title: 'Weekly summary report', sub: 'A digest of screening activity across all job postings', email: true, inApp: false },
  { key: 'expiring', title: 'Job posting expiring', sub: '7 days before an active posting is scheduled to close', email: false, inApp: true },
  { key: 'system', title: 'System & maintenance alerts', sub: 'Downtime, degraded performance, or scheduled maintenance', email: true, inApp: true },
  { key: 'product', title: 'Product updates', sub: 'New features and improvements to TalentLens', email: false, inApp: false },
];

const SettingsPage = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [notifs, setNotifs] = useState(() =>
    Object.fromEntries(NOTIF_ROWS.map((r) => [r.key, { email: r.email, inApp: r.inApp }]))
  );
  const [twoFA, setTwoFA] = useState(false);
  const [theme, setTheme] = useState('light');
  const [newPassword, setNewPassword] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  const strength = (() => {
    let score = 0;
    if (newPassword.length >= 8) score++;
    if (/[A-Z]/.test(newPassword)) score++;
    if (/[0-9]/.test(newPassword)) score++;
    if (/[^A-Za-z0-9]/.test(newPassword)) score++;
    return score;
  })();
  const strengthLabel =
    newPassword.length === 0 ? '' :
    strength <= 1 ? 'Weak — try adding numbers, symbols and a capital letter' :
    strength <= 3 ? 'Medium strength — add a symbol to make it stronger' :
    'Strong password';
  const strengthColor = strength <= 1 ? 'bg-red-500' : strength <= 3 ? 'bg-amber-500' : 'bg-green-500';

  const toggleNotif = (key, channel) =>
    setNotifs((prev) => ({ ...prev, [key]: { ...prev[key], [channel]: !prev[key][channel] } }));

  return (
    <div>
      <div className="mb-5">
        <h1 className="text-xl font-bold text-slate-900">Account settings</h1>
        <p className="mt-1 text-sm text-slate-500">Manage your profile, security, notifications and billing</p>
      </div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-[220px_1fr]">
        {/* Sub-nav */}
        <nav className="h-fit rounded-xl border border-slate-200 bg-white p-2">
          {TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`mb-0.5 flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors ${
                activeTab === tab.key ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
          <div className="my-2 h-px bg-slate-200" />
          <button
            onClick={() => setActiveTab('danger')}
            className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors ${
              activeTab === 'danger' ? 'bg-red-50 text-red-600 font-semibold' : 'text-red-600 hover:bg-red-50'
            }`}
          >
            <AlertTriangle size={16} />
            Danger zone
          </button>
        </nav>

        {/* Panels */}
        <div className="space-y-5">
          {/* ---------------- PROFILE ---------------- */}
          {activeTab === 'profile' && (
            <Card title="Profile information" subtitle="Update your photo and personal details">
              <div className="mb-6 flex items-center gap-4">
                <div className="flex h-[72px] w-[72px] items-center justify-center rounded-full bg-gradient-to-br from-blue-600 to-cyan-500 text-2xl font-bold text-white">
                  NR
                </div>
                <div>
                  <div className="flex gap-2.5">
                    <Button variant="secondary" size="sm">Upload photo</Button>
                    <Button variant="secondary" size="sm">Remove</Button>
                  </div>
                  <p className="mt-2 text-xs text-slate-400">JPG or PNG, at least 200×200px, max 5MB.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <Input label="Full name" defaultValue="Nadeesha Ranasinghe" />
                <Input label="Job title" defaultValue="HR Manager" />
                <div>
                  <Input label="Work email" type="email" defaultValue="nadeesha@talentlens.io" />
                  <span className="mt-2 inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-bold text-green-700">
                    <BadgeCheck size={12} /> Verified
                  </span>
                </div>
                <Input label="Phone number" type="tel" defaultValue="+94 77 123 4567" />
                <Input as="select" label="Department" defaultValue="Human Resources">
                  <option>Human Resources</option>
                  <option>Engineering</option>
                  <option>Operations</option>
                </Input>
                <Input label="Role" hint="assigned by your administrator" defaultValue="HR Manager" disabled />
              </div>

              <div className="mt-5 flex justify-end gap-2.5 border-t border-slate-200 pt-4">
                <Button variant="secondary">Cancel</Button>
                <Button icon={Save}>Save changes</Button>
              </div>
            </Card>
          )}

          {/* ---------------- SECURITY ---------------- */}
          {activeTab === 'security' && (
            <>
              <Card title="Change password" subtitle="Use a strong password you don't use elsewhere">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <Input className="md:col-span-2" label="Current password" type="password" placeholder="Enter current password" />
                  <div>
                    <Input
                      label="New password"
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Enter new password"
                    />
                    <div className="mt-2 flex gap-1">
                      {[0, 1, 2, 3].map((i) => (
                        <span key={i} className={`h-1 flex-1 rounded ${i < strength ? strengthColor : 'bg-slate-200'}`} />
                      ))}
                    </div>
                    {strengthLabel && <p className="mt-1.5 text-xs text-slate-500">{strengthLabel}</p>}
                  </div>
                  <Input label="Confirm new password" type="password" placeholder="Re-enter new password" />
                </div>
                <div className="mt-5 flex justify-end border-t border-slate-200 pt-4">
                  <Button>Update password</Button>
                </div>
              </Card>

              <Card
                title="Two-factor authentication"
                subtitle="Add an extra layer of security to your account"
                action={<Button variant="secondary" size="sm">Set up 2FA</Button>}
                noPadding
              >
                <div className="flex items-center justify-between gap-5 px-5 py-4">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">Require 2FA on sign-in</p>
                    <p className="mt-0.5 max-w-[440px] text-xs text-slate-500">
                      You&apos;ll be asked for a verification code from your authenticator app each time you sign in from a new device.
                    </p>
                  </div>
                  <Switch checked={twoFA} onChange={setTwoFA} />
                </div>
              </Card>

              <Card
                title="Active sessions"
                subtitle="Devices currently signed in to your account"
                action={<Button variant="dangerOutline" size="sm">Sign out all other sessions</Button>}
                noPadding
              >
                {[
                  { icon: Laptop, title: 'Chrome on Windows', sub: 'Colombo, Sri Lanka · Active now', current: true },
                  { icon: Smartphone, title: 'Safari on iPhone', sub: 'Colombo, Sri Lanka · Last active 2 hours ago' },
                  { icon: Laptop, title: 'Edge on Windows', sub: 'Kandy, Sri Lanka · Last active 6 days ago' },
                ].map((s) => (
                  <div key={s.title} className="flex items-center justify-between gap-4 border-b border-slate-100 px-5 py-3.5 last:border-0">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                        <s.icon size={17} />
                      </div>
                      <div>
                        <p className="flex items-center gap-2 text-sm font-semibold text-slate-800">
                          {s.title}
                          {s.current && (
                            <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-600">This device</span>
                          )}
                        </p>
                        <p className="mt-0.5 text-xs text-slate-500">{s.sub}</p>
                      </div>
                    </div>
                    {!s.current && <Button variant="secondary" size="sm">Sign out</Button>}
                  </div>
                ))}
              </Card>
            </>
          )}

          {/* ---------------- NOTIFICATIONS ---------------- */}
          {activeTab === 'notifications' && (
            <Card title="Notification preferences" subtitle="Choose what you're notified about, and where" noPadding>
              <div className="grid grid-cols-[1fr_80px_80px] border-b border-slate-200 px-5 py-3">
                <span className="text-xs font-semibold text-slate-500">Notification</span>
                <span className="text-center text-xs font-semibold text-slate-500">Email</span>
                <span className="text-center text-xs font-semibold text-slate-500">In-app</span>
              </div>
              {NOTIF_ROWS.map((row) => (
                <div key={row.key} className="grid grid-cols-[1fr_80px_80px] items-center border-b border-slate-100 px-5 py-3.5 last:border-0">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{row.title}</p>
                    <p className="mt-0.5 text-xs text-slate-500">{row.sub}</p>
                  </div>
                  <div className="flex justify-center">
                    <Switch checked={notifs[row.key].email} onChange={() => toggleNotif(row.key, 'email')} />
                  </div>
                  <div className="flex justify-center">
                    <Switch checked={notifs[row.key].inApp} onChange={() => toggleNotif(row.key, 'inApp')} />
                  </div>
                </div>
              ))}
            </Card>
          )}

          {/* ---------------- PREFERENCES ---------------- */}
          {activeTab === 'preferences' && (
            <>
              <Card title="Regional preferences" subtitle="Controls how dates, times and numbers are displayed">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <Input as="select" label="Language" defaultValue="English">
                    <option>English</option><option>Sinhala</option><option>Tamil</option>
                  </Input>
                  <Input as="select" label="Timezone" defaultValue="(GMT+5:30) Colombo">
                    <option>(GMT+5:30) Colombo</option><option>(GMT+0:00) London</option><option>(GMT-5:00) New York</option>
                  </Input>
                  <Input as="select" label="Date format" defaultValue="DD/MM/YYYY">
                    <option>DD/MM/YYYY</option><option>MM/DD/YYYY</option><option>YYYY-MM-DD</option>
                  </Input>
                  <Input as="select" label="Candidates per page" defaultValue="50">
                    <option>25</option><option>50</option><option>100</option>
                  </Input>
                </div>
              </Card>

              <Card title="Appearance" subtitle="Choose how TalentLens looks on your device">
                <label className="mb-1.5 block text-xs font-semibold text-slate-800">Theme</label>
                <div className="flex gap-2">
                  {[
                    { key: 'light', label: 'Light', icon: Sun },
                    { key: 'dark', label: 'Dark', icon: Moon },
                    { key: 'system', label: 'System', icon: Monitor },
                  ].map((opt) => (
                    <button
                      key={opt.key}
                      onClick={() => setTheme(opt.key)}
                      className={`flex flex-1 items-center justify-center gap-2 rounded-lg border-[1.5px] px-4 py-2.5 text-sm font-semibold transition-colors ${
                        theme === opt.key ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-slate-200 text-slate-500'
                      }`}
                    >
                      <opt.icon size={14} />
                      {opt.label}
                    </button>
                  ))}
                </div>
              </Card>

              <div className="flex justify-end">
                <Button icon={Save}>Save preferences</Button>
              </div>
            </>
          )}

          {/* ---------------- BILLING ---------------- */}
          {activeTab === 'billing' && (
            <>
              <Card>
                <div className="flex flex-wrap items-start justify-between gap-5">
                  <div>
                    <span className="mb-2 inline-block rounded-full bg-blue-50 px-2.5 py-1 text-xs font-bold text-blue-900">
                      Current plan
                    </span>
                    <h3 className="text-lg font-bold text-slate-900">Pro — 630 CVs / month</h3>
                    <p className="text-sm text-slate-500">$149/month · renews on 19 Oct 2026</p>
                  </div>
                  <div className="flex gap-2.5">
                    <Button variant="secondary">View invoices</Button>
                    <Button>Upgrade plan</Button>
                  </div>
                </div>

                <div className="mt-5 space-y-4">
                  <div>
                    <div className="mb-1.5 flex justify-between text-xs text-slate-500">
                      <span>CVs screened this cycle</span><strong className="text-slate-800">428 / 630</strong>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-600" style={{ width: '68%' }} />
                    </div>
                  </div>
                  <div>
                    <div className="mb-1.5 flex justify-between text-xs text-slate-500">
                      <span>Team seats used</span><strong className="text-slate-800">4 / 10</strong>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-600" style={{ width: '40%' }} />
                    </div>
                  </div>
                </div>
              </Card>

              <Card title="Payment method" subtitle="Used for your monthly subscription charge" action={<Button variant="secondary" size="sm">Update</Button>}>
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                    <CreditCard size={17} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">Visa ending in 4242</p>
                    <p className="text-xs text-slate-500">Expires 08/28</p>
                  </div>
                </div>
              </Card>

              <Card title="Billing history" noPadding>
                <table className="w-full text-sm">
                  <thead>
                    <tr>
                      {['Invoice', 'Date', 'Amount', 'Status', ''].map((h) => (
                        <th key={h} className="border-b border-slate-200 px-5 py-3 text-left text-xs font-semibold text-slate-500">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ['INV-2026-0091', '19 Aug 2026', '$149.00'],
                      ['INV-2026-0078', '19 Jul 2026', '$149.00'],
                      ['INV-2026-0065', '19 Jun 2026', '$149.00'],
                    ].map(([inv, date, amount]) => (
                      <tr key={inv} className="border-b border-slate-100 last:border-0">
                        <td className="px-5 py-3.5">{inv}</td>
                        <td className="px-5 py-3.5">{date}</td>
                        <td className="px-5 py-3.5">{amount}</td>
                        <td className="px-5 py-3.5"><span className="rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-700">Paid</span></td>
                        <td className="px-5 py-3.5"><a href="#" className="text-xs font-semibold text-blue-600 hover:underline">Download</a></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </>
          )}

          {/* ---------------- DANGER ZONE ---------------- */}
          {activeTab === 'danger' && (
            <Card title="Danger zone" subtitle="These actions are permanent — review carefully before continuing" className="border-red-200" noPadding>
              <div className="flex items-center justify-between gap-5 border-b border-red-100 px-5 py-4">
                <div>
                  <p className="text-sm font-semibold text-slate-800">Deactivate account</p>
                  <p className="mt-0.5 max-w-[440px] text-xs text-slate-500">
                    Temporarily disable your account. You can reactivate anytime by signing in again — your data is kept.
                  </p>
                </div>
                <Button variant="dangerOutline">Deactivate</Button>
              </div>
              <div className="flex items-center justify-between gap-5 px-5 py-4">
                <div>
                  <p className="text-sm font-semibold text-slate-800">Delete account</p>
                  <p className="mt-0.5 max-w-[440px] text-xs text-slate-500">
                    Permanently delete your account, job postings, and all screened candidate data. This cannot be undone.
                  </p>
                </div>
                <Button variant="danger" icon={Trash2} onClick={() => setShowDeleteModal(true)}>Delete account</Button>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Delete account confirmation modal */}
      {showDeleteModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 p-5"
          onClick={() => setShowDeleteModal(false)}
        >
          <div className="w-full max-w-[420px] rounded-2xl bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-red-50 text-red-600">
              <AlertTriangle size={20} />
            </div>
            <h3 className="mb-2 text-base font-bold text-slate-900">Delete your account?</h3>
            <p className="mb-4 text-sm leading-relaxed text-slate-500">
              This permanently deletes <strong className="text-slate-800">Nadeesha Ranasinghe&apos;s</strong> account, 6
              job postings, and all associated candidate data. Type <strong className="text-slate-800">DELETE</strong> to confirm.
            </p>
            <input
              type="text"
              value={deleteConfirmText}
              onChange={(e) => setDeleteConfirmText(e.target.value)}
              placeholder="Type DELETE to confirm"
              className="mb-5 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
            />
            <div className="flex justify-end gap-2.5">
              <Button variant="secondary" onClick={() => { setShowDeleteModal(false); setDeleteConfirmText(''); }}>Cancel</Button>
              <Button
                variant="danger"
                disabled={deleteConfirmText.trim() !== 'DELETE'}
                onClick={() => {
                  // TODO: await authService / accountService delete call, then sign out + redirect
                  console.log('Account deletion confirmed');
                  setShowDeleteModal(false);
                }}
              >
                Delete my account
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsPage;
